﻿const base = {
    url : "http://localhost:8080/springbootviu29/"
}
export default base
